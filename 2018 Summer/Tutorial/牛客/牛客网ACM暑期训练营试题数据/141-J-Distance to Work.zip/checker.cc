#include <bits/stdc++.h>
using namespace std;

const double eps=1e-6;

inline bool equal(double expected, double result, double MAX_DOUBLE_ERROR=eps){
  if(isnan(expected)) return isnan(result);
  if(isnan(result)) return false;
  if(isinf(expected)){
    if(expected > 0){
      return result>0 and isinf(result);
    }else{
      return result<0 and isinf(result);
    }
  }
  if(isinf(result)) return false;

  if(fabs(expected-result)<=MAX_DOUBLE_ERROR+1e-15)
    return true;

  double minv=min(expected*(1.0-MAX_DOUBLE_ERROR),
                  expected*(1.0+MAX_DOUBLE_ERROR));
  double maxv=max(expected*(1.0-MAX_DOUBLE_ERROR),
                  expected*(1.0+MAX_DOUBLE_ERROR));
  return minv <= result+1e-15 and
         maxv >= result-1e-15;
}

int main() {

  ifstream input("input");
  ifstream output("output");
  ifstream user_output("user_output");
  double x, y;

  while(output>>x){
    if(user_output>>y){
      if(not equal(x, y))
        return 1;
    }else
      return 1;
  }
  if(user_output>>y)
    return 1;
  return 0;
}
