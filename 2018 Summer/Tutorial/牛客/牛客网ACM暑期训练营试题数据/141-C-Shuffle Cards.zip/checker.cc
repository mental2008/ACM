#include <bits/stdc++.h>
using namespace std;

int main() {
  
  ifstream input("input");
  ifstream output("output");
  ifstream user_output("user_output");
  long long x, y;

  while(output>>x){
    if(user_output>>y){
      if(x!=y)
        return 1;
    }else
      return 1;
  }
  if(user_output>>y)
    return 1;
  return 0;
}
