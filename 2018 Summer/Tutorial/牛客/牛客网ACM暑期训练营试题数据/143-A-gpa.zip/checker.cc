#include<stdio.h>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<set>
#include<cmath>
#include<iostream>
#include<assert.h>
#include<queue>
#include<string>
#define rep(i,j,k) for(int i=(int)j;i<=(int)k;i++)
#define per(i,j,k) for(int i=(int)j;i>=(int)k;i--)
#define pii pair<int,int>
#define fi first
#define se second
#define pb push_back
using namespace std;
typedef long long LL;
int main(){
	freopen("output","r",stdin);
	double std;scanf("%lf",&std);
	freopen("user_output","r",stdin);
	double gt;scanf("%lf",&gt);
	if(fabs(std-gt)<2*(1e-5))return 0;
	return 1;
}