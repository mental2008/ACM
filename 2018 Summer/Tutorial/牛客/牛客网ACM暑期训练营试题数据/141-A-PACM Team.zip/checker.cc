#include <bits/stdc++.h>
//#include "testlib.h"

using namespace std;

const int N=39;

int n, p[N], a[N], c[N], m[N], g[N];
int P, A, C, M;

inline int readAndCheckAnswer(ifstream& in) {
  int k; in>>k;
  if(k<0 or k>n) return -1;
  //int k=in.readInt(0, n);

  int gP=0, gA=0, gC=0, gM=0, gG=0;
  set<int> got;
  while(k --){
    int idx; in>>idx;
    if(idx<0 or idx>n-1) return -1;
    //int idx=in.readInt(0, n-1);
    if(got.count(idx))
      return -1;
    got.insert(idx);
    gP+=p[idx];
    gA+=a[idx];
    gC+=c[idx];
    gM+=m[idx];
    gG+=g[idx];
  }
  if(gP>P or gA>A or gC>C or gM>M) return -1;
  return gG;
}

int main() {
  
  ifstream input("input");
  ifstream output("output");
  ifstream user_output("user_output");

  input>>n;
  //n=inf.readInt();
  for(int i=0; i<n; i++){
    input>>p[i]>>a[i]>>c[i]>>m[i]>>g[i];
    //p[i]=inf.readInt();
    //a[i]=inf.readInt();
    //c[i]=inf.readInt();
    //m[i]=inf.readInt();
    //g[i]=inf.readInt();
  }
  input>>P>>A>>C>>M;
  //P=inf.readInt();
  //A=inf.readInt();
  //C=inf.readInt();
  //M=inf.readInt();

  int jury_ans=readAndCheckAnswer(output);
  int contestant_ans=readAndCheckAnswer(user_output);
  //int jury_ans=readAndCheckAnswer(ans);
  //int contestant_ans=readAndCheckAnswer(ouf);

  if(jury_ans == -1) return 1;
    //quitf(_fail, "Given groups violates some constraints");
  if(contestant_ans == -1) return 1;
    //quitf(_wa, "Given groups violates some constraints");
  if(contestant_ans > jury_ans) return 1;
    //quitf(_wa,   "jury's answer %d is better(output: %d)\n", jury_ans, contestant_ans);
  if(jury_ans > contestant_ans) return 1;
    //quitf(_fail, "contestant's answer %d is better(jury: %d)\n", contestant_ans, jury_ans);
  return 0;
  //quitf(_ok, "Accepted!");
}
