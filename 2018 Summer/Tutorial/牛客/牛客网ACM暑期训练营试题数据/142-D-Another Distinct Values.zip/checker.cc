#include <cstdio>
#include <vector>
#include <iostream>
#include <fstream>

const int _ok = 0;
const int _wa = 1;

void quitf(int exit_code, const char* msg) {
  puts(msg);
  exit(exit_code);
}

int main(int argc, char** argv) {
  std::ifstream inf("input");
  std::ifstream ouf("user_output");
  int T;
  inf >> T;
  for (int cas = 1; cas <= T; ++cas) {
    int n;
    inf >> n;
    std::string out;
    ouf >> out;
    if (n % 2 == 1) {
      if (out != "impossible") quitf(_wa, "expect impossible");
    } else {
      if (out != "possible") quitf(_wa, "expect possible");
      std::vector<int> sum(n + n);
      for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
          int x;
          ouf >> x;
          if (x != -1 && x != 0 && x != 1) quitf(_wa, "not in [-1, 0, 1]");
          sum[i] += x;
          sum[j + n] += x;
        }
      }
      for (int i = 0; i < n * 2; ++i) {
        for (int j = 0; j < i; ++j) {
          if (sum[i] == sum[j]) quitf(_wa, "duplicate sum");
        }
      }
    }
  }
  quitf(_ok, "ok");
  return 0;
}