#include <iostream>
#include <fstream>
#include <vector>

using int64 = long long;

const int _ok = 0;
const int _wa = 1;
const int _fail = 2;

void quitf(int exit_code, const char* msg) {
  puts(msg);
  exit(exit_code);
}

int main(int argc, char** argv) {
  std::ifstream inf("input");
  std::ifstream ans("output");
  std::ifstream ouf("user_output");
  int T;
  inf >> T;
  for (int cas = 1; cas <= T; ++cas) {
    int n;
    inf >> n;
    std::vector<int> a(n), b(n), c(n);
    for (int i = 0; i < n; ++i) {
      inf >> a[i] >> b[i] >> c[i];
      --a[i], --b[i], --c[i];
    }
    std::vector<int> out(n * 3);
    int64 dis_ans = 0;
    for (int i = 0; i < n * 3; ++i) {
      ans >> out[i];
      if (i) dis_ans += std::abs(out[i] - out[i - 1]);
    }
    std::vector<bool> mark(n * 3);
    std::vector<int> pos(n * 3);
    int64 dis_out = 0;
    for (int i = 0; i < n * 3; ++i) {
      ouf >> out[i];
      if (mark[out[i] - 1]) {
        quitf(_wa, "duplicate element");
      }
      mark[out[i] - 1] = 1;
      pos[out[i] - 1] = i;
      if (i) dis_out += std::abs(out[i] - out[i - 1]);
    }
    for (int i = 0; i < n; ++i) {
      if (pos[a[i]] > pos[b[i]] || pos[a[i]] > pos[c[i]]) {
        quitf(_wa, "some restrictions failed");
      }
    }
    if (dis_out < dis_ans) {
      quitf(_fail, "user is better");
    }
    if (dis_out > dis_ans) {
      quitf(_wa, "jury is better");
    }
  }
  quitf(_ok, "ok");
  return 0;
}